#include <stdio.h>
#include "f.h"
// Validate the identifier
int checkIdentifier(char *str)
{
    if (!(isalpha(str[0]) || str[0] == '_'))
    {
        printf("Error: Invalid Identifier -> %s\n", str);
        return 0;
    }

    for (int i = 1; str[i] != '\0'; i++)
    {
        if (!(isalnum(str[i]) || str[i] == '_'))
        {
            printf("Error: Invalid Identifier -> %s\n", str);
            return 0;
        }
    }

    return 1;
}
// Cheking hexadecimal  value
int checkHex(char *str)
{
    if (!(str[0] == '0' && (str[1] == 'x' || str[1] == 'X')))
        return 0;

    
    if (str[2] == '\0')
    {
        printf("Error: Invalid Hexadecimal -> %s\n", str);
        return 0;
    }

    for (int i = 2; str[i] != '\0'; i++)
    {
        if (!((str[i] >= '0' && str[i] <= '9') ||
              (str[i] >= 'a' && str[i] <= 'f') ||
              (str[i] >= 'A' && str[i] <= 'F')))
        {
            printf("Error: Invalid Hexadecimal -> %s\n", str);
            return 0;
        }
    }

    printf("%s - Hexadecimal Constant\n", str); 

    return 1;
}
// Cheking Octal  value
int checkOctal(char *str)
{

    if (str[0] != '0')
        return 0;

    for (int i = 1; str[i] != '\0'; i++)
    {
        if (str[i] < '0' || str[i] > '7')
        {
            printf("Error: Invalid Octal -> %s\n", str);
            return 0;
        }
    }

   
    printf("%s - Octal Constant\n", str);

    return 1;
}
// Cheking Binary value
int checkBinary(char *str)
{
    if (!(str[0] == '0' && (str[1] == 'b' || str[1] == 'B')))
        return 0;

    
    if (str[2] == '\0')
    {
        printf("Error: Invalid Binary -> %s\n", str);
        return 0;
    }

    for (int i = 2; str[i] != '\0'; i++)
    {
        if (!(str[i] == '0' || str[i] == '1'))
        {
            printf("Error: Invalid Binary -> %s\n", str);
            return 0;
        }
    }

   
    printf("%s - Binary Constant\n", str);

    return 1;
}
char stack[100];
int top = -1;

// Check the bracket opening and closing

int checkBracket(char ch)
{
    // Opening brackets
    if (ch == '(' || ch == '{' || ch == '[')
    {
        if (top == 99)
        {
            printf("Error: Bracket stack overflow.\n");
            return 0;
        }

        stack[++top] = ch;
        return 1;
    }

    // Closing ')'
    if (ch == ')')
    {
        if (top == -1 || stack[top] != '(')
        {
            printf("Error: ')' Mismatch\n");
            return 0;
        }

        top--;
        return 1;
    }

    // Closing '}'
    if (ch == '}')
    {
        if (top == -1 || stack[top] != '{')
        {
            printf("Error: '}' Mismatch\n");
            return 0;
        }

        top--;
        return 1;
    }

    // Closing ']'
    if (ch == ']')
    {
        if (top == -1 || stack[top] != '[')
        {
            printf("Error: ']' Mismatch\n");
            return 0;
        }

        top--;
        return 1;
    }

    // Not a bracket
    return 1;
}
// check last flower bracket
int checkBracketEnd()
{
    if (top == -1)
        return 1;

    while (top != -1)
    {
        printf("Error: '%c' was opened but not closed.\n", stack[top]);
        top--;
    }

    return 0;      
}
// Check  Quote for string
int checkDoubleQuote(char *line)
{
    int count = 0;

    for (int i = 0; line[i] != '\0'; i++)
    {
        if (line[i] == '"')
            count++;
    }

    if (count % 2 != 0)
    {
        printf("Error: Double Quote was opened but not closed.\n");   
        return 0;
    }

    return 1;    
}
// Cheking single brace
int checkSingleQuote(char *line)
{
    int count = 0;

    for (int i = 0; line[i] != '\0'; i++)
    {
        if (line[i] == '\'')
            count++;
    }

    if (count % 2 != 0)
    {
       
        printf("Error: Single Quote was opened but not closed.\n");
        return 0;
    }

    return 1;
}
// Cheking Floating  value
int checkFloat(char *str)
{
    int i = 0;
    int dot = 0;
    int digitBefore = 0;
    int digitAfter = 0;

    if (str[0] == '+' || str[0] == '-')
        i++;

    for (; str[i] != '\0'; i++)
    {
        if (isdigit(str[i]))
        {
            if (dot)
                digitAfter = 1;
            else
                digitBefore = 1;
        }
        else if (str[i] == '.')
        {
            if (dot)
            {
                printf("Error: Invalid Floating Constant -> %s\n", str);
                return 0;
            }
            dot = 1;
        }
        else
        {
            printf("Error: Invalid Floating Constant -> %s\n", str);
            return 0;
        }
    }

    if (dot)
    {
        if (!digitBefore || !digitAfter)
        {
            printf("Error: Invalid Floating Constant -> %s\n", str);
            return 0;
        }

        printf("%s - Floating Constant\n", str);
        return 1;
    }

    return -1;      
}