#ifndef FUNCTION_H
#define FUNCTION_H

#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include <stdlib.h>

extern const char *keywords[];
extern const char *operators;
extern const char *specialCharacters;

/* function.c */
int isvalid(char *);
int check(char *);
int keyword(char *);
int specialchar(char );
int oprator(char );
int isconst(char *);

/* error.c */

// Identifier validation
int checkIdentifier(char *);

// Hexadecimal validation
int checkHex(char *);

// Octal validation
int checkOctal(char *);

// Binary validation
int checkBinary(char *);

// Floating constant validation
int checkFloat(char *);

// Bracket checking
int checkBracket(char);      // <-- changed from void to int
int checkBracketEnd();

// Quote checking
int checkDoubleQuote(char *);
int checkSingleQuote(char *);

#endif