#include <stdio.h>
#include "f.h"

#define size 100
int flag;
const char *keywords[] = {
    "int", "float", "return", "if", "else", "while", "for", "do", "break", "continue",
    "char", "double", "void", "switch", "case", "default", "const", "static", "sizeof", "struct"};

const char *operators = "+-*/%=!<>|&";
const char *specialCharacters = ",;{}()[]";

char *ch = "#include";
// char stk[50];
// int top = -1;

int isvalid(char *str)
{
    char *ptr = strchr(str, '.');

    if (ptr == NULL || strcmp(ptr, ".txt") != 0)
    {
        printf("Please give the Correct Extension File.\n");
        return 0;
    }

    printf("Valid file: %s\n", str);
    return 1;
}

// Integral and Floating constants
int isconst(char *buffer)
{
    if (strchr(buffer, '.') == NULL &&
        buffer[0] >= '0' && buffer[0] <= '9')
    {

        int num = atoi(buffer);
        printf("%d - Integral Constant\n", num);
        return 1;
    }
    else if (buffer[0] >= '0' && buffer[0] <= '9')
    {
        float num = atof(buffer);
        printf("%f - Floating Constant\n", num);
        return 1;
    }

    return 0;
}

// Keyword check
int keyword(char *buffer)
{
    for (int i = 0; i < 20; i++)
    {
        if (strcmp(keywords[i], buffer) == 0)
        {
            printf("%s - Keyword\n", buffer);
            return 1;
        }
    }

    return 0;
}

// Special Character
int specialchar(char ch)
{
    
    if (strchr(specialCharacters, ch) != NULL)
    {
        if (checkBracket(ch) == 0)
            return 2;

        printf("%c - Special Character\n", ch);
        flag = 1;
        return 1;
    }

    flag = 0;
    return 0;
}

// Operator
int oprator(char ch)
{
    
    if (strchr(operators, ch) != NULL)
    {
        printf("%c - Operator\n", ch);
        flag = 1;
        return 1;
    }

    flag = 0;
    return 0;
}
// Checking the token, validating it, and printing the result
int processToken(char *token)
{
    if (keyword(token))
        return 1;

    if (isdigit(token[0]))
    {
        if (token[0] == '0' && (token[1] == 'x' || token[1] == 'X'))
        {
            if (!checkHex(token))
                return 0;

            printf("%s - Hexadecimal Constant\n", token);
        }
        else if (token[0] == '0' && (token[1] == 'b' || token[1] == 'B'))
        {
            if (!checkBinary(token))
                return 0;

            printf("%s - Binary Constant\n", token);
        }
        else if (strchr(token, '.') != NULL)
        {
            if (checkFloat(token) == 0)
                return 0;
        }
        else
        {
            for (int i = 0; token[i] != '\0'; i++)
            {
                if (isalpha(token[i]) || token[i] == '_')
                {
                    printf("Error: Invalid Identifier -> %s\n", token);
                    return 0;
                }
            }

            if (token[0] == '0')
            {
                if (!checkOctal(token))
                    return 0;

                printf("%s - Octal Constant\n", token);
            }
            else
            {
                isconst(token);
            }
        }
    }
    else
    {
        if (!checkIdentifier(token))
            return 0;

        printf("%s - Identifier\n", token);
    }

    return 1;
}


// Main Checking
int check(char *buffer)
{
    if (strstr(buffer, "#include"))
    {
        printf("%s - Header File\n", buffer);
        return 1;
    }

    char token[100];
    int k = 0;

    for (int i = 0; buffer[i] != '\0'; i++)
    {
        char ch = buffer[i];

        int sp = specialchar(ch);

        if (sp == 2)
            return 0;

        if (sp == 1)
        {
            if (k > 0)
            {
                token[k] = '\0';

                if (!processToken(token))
                    return 0;

                k = 0;
            }

            continue;
        }

        if (oprator(ch))
        {
            if (k > 0)
            {
                token[k] = '\0';

                if (!processToken(token))
                    return 0;

                k = 0;
            }

            continue;
        }

        if (isspace(ch))
        {
            if (k > 0)
            {
                token[k] = '\0';

                if (!processToken(token))
                    return 0;

                k = 0;
            }

            continue;
        }

        if (k >= 99)
        {
            printf("Error: Token too long\n");
            return 0;
        }

        token[k++] = ch;
    }

    if (k > 0)
    {
        token[k] = '\0';

        if (!processToken(token))
            return 0;
    }

    checkDoubleQuote(buffer);
    checkSingleQuote(buffer);

    return 1;
}