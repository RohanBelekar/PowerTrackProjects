#include <stdio.h>
#include "f.h"

int main(int argc, char *argv[])
{
    // Checking the Count and the validation
    if (argc < 2)
    {
        printf("Include the File\n");
        return 0;
    }

    if (!isvalid(argv[1]))
        return 0;

    // Open file
    FILE *fp = fopen(argv[1], "r");

    if (fp == NULL)
    {
        printf("Error: Could not open file %s\n", argv[1]);
        return 0;
    }

    char buffer[100];
    // Scanning the word from file

    while (fscanf(fp, "%99s", buffer) != EOF)      
    {
        if (!check(buffer))
        {
            fclose(fp);
            return 0;
        }
    }

    // Cheking last bracket 
    if (!checkBracketEnd())
    {
        fclose(fp);
        return 0;
    }

    fclose(fp);

    printf("\nLexical Analysis Completed Successfully.\n");  

    return 1;
}